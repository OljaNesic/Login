import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

import java.util.Random;
import java.util.concurrent.TimeUnit;

public class SauceDemoTest {

    WebDriver driver;

    @BeforeMethod
    public void setup(){
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

        driver.get("https://www.saucedemo.com/");
    }

    @AfterMethod
    public void tearDown(){
        driver.quit();
    }

    @Test
    @Parameters({"username","password","testType","errorMessage"})
    public void loginValidCredentials(String username, String password, String testType, @Optional String errorMessage){

        if(!username.equalsIgnoreCase("NULL")) {
            driver.findElement(By.cssSelector("#user-name")).sendKeys(username);
        }
        driver.findElement(By.cssSelector("#password")).sendKeys(password);
        driver.findElement(By.cssSelector("#login-button")).click();

        if(testType.equalsIgnoreCase("positive")) {
            Assert.assertEquals(driver.getCurrentUrl(), "https://www.saucedemo.com/inventory.html");
        }
        else {
            Assert.assertEquals(driver.findElement(By.cssSelector("[data-test='error']")).getText(), errorMessage);
        }
    }

//    Random random = new Random();
//    int x = random.nextInt(100000);

//    long x = System.currentTimeMillis();
//    String email = "pera"+x+"@pera.com";

}